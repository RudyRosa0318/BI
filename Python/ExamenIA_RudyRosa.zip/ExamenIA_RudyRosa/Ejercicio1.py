# Programa: Ejercicio1.py
# Objetivo: Examen I Parcial
# Autor: Rudy Rosa
# Fecha: 17/febrero/2020

import math

def triangular(numero):
    """
    obtiene el numero triangular que sea igual a pentagonal

    parametros: numero
    numero:es el valor a utilizar en la formulas dentro de la funcion
    """


    t = print("Triangular",round(math.sqrt(((2 * numero)  - 1))))
    p = print("Pentagonal",round(math.sqrt((2*numero + 1)/3)))
    h = print("Hexagonal",round(math.sqrt((numero + 1)/2)))
    print("numero en comun es")
    return numero
if __name__ == "__main__":
     print(triangular(1533776805))

