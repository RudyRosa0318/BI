# Programa: Ejercicio1.py
# Objetivo: Examen I Parcial
# Autor: Rudy Rosa

import math

def numeros_abundantes():
    for i in range(2,100):
        if (100 % i == 0):
            print(i)

    suma =sum(i for i in range (2,100) if (100 % i == 0))
    print("Resultado sumado",suma+1)
    if (suma >= 100):
        print("Abundante(se le sumo el 1 dentro)")
    elif (suma <= 100):
        print("Deficiente(se le sumo el 1 dentro)")
    elif (suma == 100):
        print("Perfecto(se le sumo el 1 dentro)")
           
    
if __name__ == "__main__":
    numeros_abundantes()